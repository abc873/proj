<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$hid = $_POST['H_ID'];
	$hname= $_POST['H_NAME'];
	$haddr = $_POST['H_ADDR'];
	$hphno = $_POST['H_PHNO'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO hosp_info(HID,H_NAME,H_ADDR,H_PHNO) VALUES('$hid','$hname','$haddr',$hphno)";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=HOSP_INFO.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE hosp_info SET H_NAME='$hname',H_ADDR='$haddr',H_PHNO='$hphno' WHERE H_ID='$hid'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=HOSP_INFO.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM hosp_info WHERE H_ID='$hid'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=HOSP_INFO.html");
	}
	
	if(isset($_POST['dispHOSPINFO'])) {
		
		$sp = "CALL disp_tabs('hosp_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>HOSPITAL ID</th><th>HOSPITAL NAME</th><th>ADDRESS</th><th>PHONE NUMBER</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['HID']}</td><td>{$row['H_NAME']}</td><td>{$row['H_ADDR']}</td><td>{$row['H_PHNO']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}