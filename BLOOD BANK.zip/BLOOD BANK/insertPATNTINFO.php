<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$pid = $_POST['P_ID'];
	$pfname= $_POST['P_FNAME'];
	$plname = $_POST['P_LNAME'];
	$paddr = $_POST['P_ADDR'];
	$gender = $_POST['GENDER'];
	$bgrp = $_POST['BLOOD_GRP'];
	$mrpts = $_POST['MED_RPTS'];
	$hid = $_POST['H_ID'];
	$docid = $_POST['DOC_ID'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO patient_info(P_ID,P_FNAME,P_LNAME,P_ADDR,GENDER,BLOOD_GRP,MED_RPTS,HID,DOC_ID) VALUES('$pid','$pfname','$plname','$paddr','$gender','$bgrp','$mrpts','$hid','$docid')";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=patient info.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE patient_info SET P_FNAME='$pfname',P_LNAME='$plname',P_ADDR='$paddr',GENDER='$gender',BLOOD_GRP='$bgrp',MED_RPTS='$mrpts',HID='$hid',DOC_ID='$docid', WHERE P_ID='$pid'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=patient info.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM patient_info WHERE P_ID='$pid'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=patient info.html");
	}
	
	if(isset($_POST['dispPATINFO'])) {
		
		$sp = "CALL disp_tabs('patient_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>PATIENT ID</th><th>FIRST NAME</th><th>LAST NAME</th><th>ADDRESS</th><th>GENDER</th><th>BLOOD GROUP</th><th>MEDICAL REPORTS</th><th>HOSPITAL ID</th><th>DOCTOR ID</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['P_ID']}</td><td>{$row['P_FNAME']}</td><td>{$row['P_LNAME']}</td><td>{$row['P_ADDR']}</td><td>{$row['GENDER']}</td><td>{$row['BLOOD_GRP']}</td><td>{$row['MED_RPTS']}</td><td>{$row['HID']}</td><td>{$row['DOC_ID']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}