<?php
	
	$con = mysqli_connect('localhost','root','','blood_bank');
	
	$query = "SELECT P.* from (patient_info P JOIN doc_info D ON P.DOC_ID = D.DOC_ID) JOIN hosp_info H ON P.HID = H.HID WHERE P.P_LNAME = '' AND D.DOC_NAME = 'Mohan Rao' AND H.H_NAME = 'KMC'";
	
	$query_result = mysqli_query($con,$query);

	echo"<center>";
	echo"<h2>QUERY: LIST DETAIL OF PATIENTS	</h2>";
	
	echo"<table border=1>";
	echo"<tr><th>PATIENT ID</th><th>FIRST NAME</th><th>LAST NAME</th><th>ADDRESS</th><th>GENDER</th><th>BLOOD GROUP</th><th>MEDICAL REPORT</th><th>HOSPITAL ID</th><th>DOCTOR ID</th></tr>";
	while($row = mysqli_fetch_assoc($query_result)) {
	echo"<tr><td>{$row['P_ID']}</td><td>{$row['P_FNAME']}</td><td>{$row['P_LNAME']}</td><td>{$row['P_ADDR']}</td><td>{$row['GENDER']}</td><td>{$row['BLOOD_GRP']}</td><td>{$row['MED_RPTS']}</td><td>{$row['HID']}</td><td>{$row['DOC_ID']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
?>