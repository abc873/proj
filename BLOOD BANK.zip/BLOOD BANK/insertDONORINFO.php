<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$did = $_POST['D_ID'];
	$dname= $_POST['D_NAME'];
	$daddr = $_POST['D_ADDR'];
	$dphno = $_POST['D_PHNO'];
	$dob = $_POST['DOB'];
	$gender = $_POST['GENDER'];
	$dbgrp= $_POST['D_BLD_GRP'];
	$medrpts = $_POST['MED_RPTS'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO donor_info(DID,D_NAME,D_ADDR,D_PHNO,DOB,GENDER,D_BLD_GRP,MEDICAL_RPTS) VALUES('$did','$dname','$daddr','$dphno','$dob','$gender','$dbgrp','$medrpts')";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=DONOR_INFO.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE donor_info SET D_NAME='$dname',D_ADDR='$daddr',D_PHNO='$dphno',DOB='$dob',GENDER='$gender',D_BLD_GRP='$dbgrp',MEDICAL_RPTS='$medrpts' WHERE DID='$did'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=DONOR_INFO.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM donor_info WHERE DID='$did'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=DONOR_INFOH.html");
	}
	
	if(isset($_POST['dispDONINFO'])) {
		
		$sp = "CALL disp_tabs('donor_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>DONOR ID</th><th>DONOR NAME</th><th>ADDRESS</th><th>PHONE NUMBER</th><th>DATE OF BIRTH</th><th>GENDER</th><th>DONOR BLOOD GROUP</th><th>MEDICAL REPORT</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['DID']}</td><td>{$row['D_NAME']}</td><td>{$row['D_ADDR']}</td><td>{$row['D_PHNO']}</td><td>{$row['DOB']}</td><td>{$row['GENDER']}</td><td>{$row['D_BLD_GRP']}</td><td>{$row['MEDICAL_RPTS']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}