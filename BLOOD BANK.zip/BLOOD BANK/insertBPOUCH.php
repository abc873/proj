<?php
	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');
	
	$bbid = $_POST['BB_ID'];
	$bgname = $_POST['BLOOD_GRP'];
	$qty = $_POST['QUANTITY_IN_LTRS'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO blood_pouch(BB_ID,BLOOD_GRP,QUANTITY_IN_LTRS) VALUES('$bbid','$bgname',$qty)";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=BLOOD_POUCH.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE blood_pouch SET QUANTITY_IN_LTRS =$qty WHERE BBID='$bbid' AND BLOOD_GRP='$bgname'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=BLOOD_POUCH.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM blood_pouch WHERE BBID='$bbid' AND BLOOD_GRP='$bgname'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=BLOOD_POUCH.html");
	}
	
	if(isset($_POST['dispBPINFO'])) {
		
		$sp = "CALL disp_tabs('blood_pouch')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>BLOOD BANK ID</th><th>BLOOD GROUP</th><th>QUANTITY IN LITRES</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['BB_ID']}</td><td>{$row['BLOOD_GRP']}</td><td>{$row['QUANTITY_IN_LTRS']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	} 