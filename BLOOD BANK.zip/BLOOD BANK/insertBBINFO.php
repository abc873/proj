<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$name = $_POST['BB_NAME'];
	$bbid = $_POST['BB_ID'];
	$bbaddr = $_POST['BB_ADDR'];
	$bbphno = $_POST['BB_PHNO'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO bb_info(BBID,BB_NAME,BB_ADDR,BB_PHNO) VALUES('$bbid','$name','$bbaddr',$bbphno)";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=BB_INFO.html");
	}
	
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE bb_info SET `BB_NAME='$name',BB_ADDR='$bbaddr',BB_PHNO='$bbphno' WHERE BBID='$bbid'";
		$update_result=mysqli_query($con, $update_query);
		if($update_result){
			if(mysqli_affected_rows($con)>0){
				echo("data updated");
			}else{
				echo("data not updated");
			}
		}
	header("refresh:2; url=BB_INFO.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM bb_info WHERE BBID='$bbid'";
		$delete_result = mysqli_query($con, $delete_query);
		if($delete_result){
			if(mysqli_affected_rows($con)>0)
			{
				echo("data deleted");
			}else{
				echo("data not deleted");
			}
		}
		header("refresh:2; url=BB_INFO.html");
	}
	
	if(isset($_POST['dispBBINFO'])) {
		
		$sp = "CALL disp_tabs('bb_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>BLOOD BANK NAME</th><th>BLOOD BANK ID</th><th>ADDRESS</th><th>PHONE NUMBER</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['BB_NAME']}</td><td>{$row['BBID']}</td><td>{$row['BB_ADDR']}</td><td>{$row['BB_PHNO']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}
?>