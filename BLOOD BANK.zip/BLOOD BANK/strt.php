<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: strt.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: strt.php");
	}

?>
<html>
<head>
<title>WELCOME TO BLOOD BANK DATABASE</title>

<style>input{
	height: 40px;
	width: 95%;
	background: #FFFFFF;
	padding-left:10px;
	font-size: 18px;
	border-radius: 5px;
	border: 1px red;
}
form{
	width: 40%;
	padding: 2px;
	border: 1px solid #A93226;
	background: #A93226;
	border-radius: 10px 10px 10px 10px;
}
body{
	margin-top: 250px;
	
}
</style>
</head>
<body background="#f8f8f8">
<center>
<form action="login.php">
<?php include('login.php') ?><center>
<input type="submit" value="LOGIN"></center>
</form>
<form action="register.php" method="POST"><center>
<input type="submit" value="REGISTER"></center>
</form>

<br></center>
</body>
</html>	

