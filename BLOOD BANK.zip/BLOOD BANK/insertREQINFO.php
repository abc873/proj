<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$rid = $_POST['R_ID'];
	$bloodgrp = $_POST['BLOOD_GRP'];
	$qty = $_POST['QTY_REQ_IN_MLTRS'];
	$hid = $_POST['H_ID'];
	$pid = $_POST['P_ID'];
	$bbid =$_POST['BB_ID'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO req_info(R_ID,BLOOD_GRP,QTY_REQ_IN_MLTRS,HID,P_ID,BB_ID) VALUES('$rid','$bloodgrp',$qty,'$hid','$pid','$bbid')";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=req info.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE req_info SET BLOOD_GRP='$bloodgrp',QTY_REQ_IN_LTRS='$qty',HID='$hid',P_ID='$pid',BB_ID='$bbid' WHERE R_ID='$rid'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=req info.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM req_info WHERE R_ID='$rid'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=req info.html");
	}
	
	if(isset($_POST['dispREQINFO'])) {
		
		$sp = "CALL disp_tabs('req_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>REQUEST ID</th><th>BLOOD GROUP</th><th>QUANTITY REQUESTED(in L)</th><th>HOSPITAL ID</th><th>PATIENT ID</th><th>BLOOD BANK ID</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['R_ID']}</td><td>{$row['BLOOD_GRP']}</td><td>{$row['QTY_REQ_IN_LTRS']}</td><td>{$row['HID']}</td><td>{$row['P_ID']}</td><td>{$row['BB_ID']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}