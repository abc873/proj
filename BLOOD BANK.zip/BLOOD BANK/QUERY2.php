<?php
	
	$con = mysqli_connect('localhost','root','','blood_bank');
	
	$query = "SELECT count(*) from donor_info where GENDER = 'female' and D_BLD_GRP = 'O-ve'";
	
	$query_result = mysqli_query($con,$query);
	echo"<center>";
	echo"<h2>QUERY: COUNT NUMBER OF FEMALE DONORS WITH BLOOD GROUP O-ve</h2>";
	
	echo"<table border=1>";
	echo"<tr><th>COUNT(*)</th></tr>";
	while($row = mysqli_fetch_assoc($query_result)) {
		echo"<tr><td>{$row['count(*)']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
?>