<?php
	
	$con = mysqli_connect('localhost','root','','blood_bank');
	
	$query = "SELECT BB_ID,count(*) from req_info ri,bb_info bb where ri.BB_ID=bb.BBID group by BBID";
	
	$query_result = mysqli_query($con,$query);
	echo"<center>";
	echo"<h2>QUERY: NUMBER OF REQUEST HANDLED BY EACH BLOOD BANK</h2>";
	
	echo"<table border=1>";
	echo"<tr><th>BLOOD BANK ID</th><th>COUNT(*)</th></tr>";
	while($row = mysqli_fetch_assoc($query_result)) {
		echo"<tr><td>{$row['BB_ID']}</td><td>{$row['count(*)']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
?>