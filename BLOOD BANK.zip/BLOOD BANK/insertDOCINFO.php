<?php

	$con = mysqli_connect('localhost', 'root', '', 'blood_bank');

	$docid = $_POST['DOC_ID'];
	$docname= $_POST['DOC_NAME'];
	$docaddr = $_POST['DOC_ADDR'];
	$docphno = $_POST['DOC_PHNO'];
	$spl = $_POST['SPECIALISATION'];
	$hid = $_POST['HID'];
	
	if(isset($_POST['insert'])){
		
	$query = "INSERT INTO doc_info(DOC_ID,DOC_NAME,DOC_ADDR,DOC_PHNO,SPECIALISATION,H_ID) VALUES('$docid','$docname','$docaddr','$docphno','$spl','$hid')";
	
	$result = mysqli_query($con,$query);
	
	if($result)
		{
			if(mysqli_affected_rows($con)>0){
				echo("data inserted successfully");
				
			}else{
				echo("data are not inserted");
			}
		}
		header("refresh:2; url=doc_info.html");
	}
	
	if(isset($_POST['update'])){
		
	$update_query="UPDATE doc_info SET DOC_NAME='$docname',DOC_ADDR='$docaddr',DOC_PHNO='$docphno',SPECIALISATION='$spl',H_ID='$hid' WHERE DOC_ID='$docid'";
	
		$update_result=mysqli_query($con, $update_query);
		
		if($update_result){
			
			if(mysqli_affected_rows($con)>0){
				
				echo("data updated");
				
			}else{
				
				echo("data not updated");
				
			}
			
		}
	header("refresh:2; url=doc_info.html");
	}
	
	if(isset($_POST['delete'])){
		
	$delete_query = "DELETE FROM doc_info WHERE DOC_ID='$docid'";
	
		$delete_result = mysqli_query($con, $delete_query);
		
		if($delete_result){
			
			if(mysqli_affected_rows($con)>0)
			{
				
				echo("data deleted");
				
			}else{
				
				echo("data not deleted");
				
			}
		}
		header("refresh:2; url=doc_info.html");
	}
	
	if(isset($_POST['dispDOCINFO'])) {
		
		$sp = "CALL disp_tabs('doc_info')";
		$result = mysqli_query($con,$sp);
		if($result) {
			echo"<center>";
			echo"<table border=1>";
	echo"<tr><th>DOCTOR ID</th><th>DOCTOR NAME</th><th>ADDRESS</th><th>PHONE NUMBER</th><th>SPECIALISATION</th><th>HOSPITAL ID</th></tr>";
	while($row = mysqli_fetch_assoc($result)) {
		echo"<tr><td>{$row['DOC_ID']}</td><td>{$row['DOC_NAME']}</td><td>{$row['DOC_ADDR']}</td><td>{$row['DOC_PHNO']}</td><td>{$row['SPECIALISATION']}</td><td>{$row['H_ID']}</td></tr>";
	}
	echo"</table>";
	echo"</center>";
		}
		
	}